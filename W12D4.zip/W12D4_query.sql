/*ToysGroup è un’azienda che distribuisce articoli (giocatoli) in diverse aree geografiche del mondo.
I prodotti sono classificati in categorie e i mercati di riferimento dell’azienda sono classificati in regioni di vendita.
In particolare: Le entità individuabili in questo scenario sono le seguenti:
❏- Product
❏- Region
❏- Sales 
Le relazioni tra le entità possono essere descritte nel modo seguente:
❏ Product e Sales
❏ Un prodotto può essere venduto tante volte (o nessuna) per cui è contenuto in una o più transazioni di vendita.
❏ Ciascuna transazione di vendita è riferita ad uno solo prodotto
❏ Region e Sales
❏ Possono esserci molte o nessuna transazione per ciascuna regione 
❏ Ciascuna transazione di vendita è riferita ad una sola regione 
Fornisci schema concettuale e schema logico.
Crea e popola le tabelle utilizzando dati a tua discrezione (sono sufficienti pochi record per tabella; riporta le query utilizzate).
Dopo la creazione e l’inserimento dei dati nelle tabelle, esegui e riporta delle query utili a:
1. Verificare che i campi definiti come PK siano univoci.
2. 3. 4. 5. 6. Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno. 
Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente.
Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato?
Rispondere alla seguente domanda: quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti.
Esporre l’elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita più recente).
Effettua la consegna dell’esercizio utilizzando due file: Un file che contenga il diagramma ER per la progettazione del database.
Un file .sql che contenga tutte le query necessarie a creare, popolare le tabelle e rispondere ai quesiti della slide precedente.
Buon lavoro!*/

-- Creo un nuovo schema dal nome toysgroup
CREATE SCHEMA toysgroup;

-- Imposto lo schema creato di default
USE toysgroup;

-- Creo la tabella product
CREATE TABLE toysgroup.product (
  idproduct INT NOT NULL AUTO_INCREMENT,
  productname VARCHAR(30) NOT NULL,
  category VARCHAR(45),
  idsales INT NOT NULL,
  price DECIMAL(10,2),
  PRIMARY KEY (idproduct));
  
-- Creo la tabella region
CREATE TABLE toysgroup.region (
idregion INT NOT NULL AUTO_INCREMENT,
regionname VARCHAR(30) NOT NULL,
zone VARCHAR(20) NOT NULL,
 PRIMARY KEY (idregion));
 
-- Creo la tabella sales 
CREATE TABLE toysgroup.sales (
idsales INT NOT NULL AUTO_INCREMENT,
idregion INT NOT NULL,
salesdate DATE,
PRIMARY KEY (idsales));
-- N.B.:calcolo il fatturato come campo calcolato nelle query apposite (vedasi query interrogative).

-- Aggiungo la foreign key productsales
ALTER TABLE `toysgroup`.`product` 
ADD INDEX `productsales_idx` (`idsales` ASC) VISIBLE;
;
ALTER TABLE `toysgroup`.`product` 
ADD CONSTRAINT `productsales`
  FOREIGN KEY (`idsales`)
  REFERENCES `toysgroup`.`sales` (`idsales`)
  ON DELETE CASCADE
  ON UPDATE CASCADE;
  
-- Aggiungo la foreign key salesregion
ALTER TABLE `toysgroup`.`sales` 
ADD INDEX `salesregion_idx` (`idregion` ASC) VISIBLE;
;
ALTER TABLE `toysgroup`.`sales` 
ADD CONSTRAINT `salesregion`
  FOREIGN KEY (`idregion`)
  REFERENCES `toysgroup`.`region` (`idregion`)
  ON DELETE CASCADE
  ON UPDATE CASCADE;
  
-- Inserisco le righe nella tabella region
INSERT INTO `toysgroup`.`region`
VALUES ('1','Abruzzo', 'Centro');
INSERT INTO `toysgroup`.`region`
VALUES ('2','Basilicata','Sud');
INSERT INTO `toysgroup`.`region`
VALUES ('3','Calabria', 'Sud');
INSERT INTO `toysgroup`.`region`
VALUES ('4','Campania', 'Sud');
INSERT INTO `toysgroup`.`region`
VALUES ('5','Emilia Romagna', 'Nord');
INSERT INTO `toysgroup`.`region`
VALUES ('6','Friuli Venezia Giulia', 'Nord');
INSERT INTO `toysgroup`.`region`
VALUES ('7','Lazio', 'Centro');
INSERT INTO `toysgroup`.`region`
VALUES ('8','Liguria', 'Nord');
INSERT INTO `toysgroup`.`region`
VALUES ('9','Lombardia', 'Nord');
INSERT INTO `toysgroup`.`region`
VALUES ('10','Marche', 'Centro');
INSERT INTO `toysgroup`.`region`
VALUES ('11','Molise', 'Centro');
INSERT INTO `toysgroup`.`region`
VALUES ('12','Piemonte', 'Nord');
INSERT INTO `toysgroup`.`region`
VALUES ('13','Puglia', 'Sud');
INSERT INTO `toysgroup`.`region`
VALUES ('14','Sardegna', 'Isole');
INSERT INTO `toysgroup`.`region`
VALUES ('15','Sicilia', 'Isole');
INSERT INTO `toysgroup`.`region`
VALUES ('16','Toscana', 'Centro');
INSERT INTO `toysgroup`.`region`
VALUES ('17','Trentino Alto Adige', 'Nord');
INSERT INTO `toysgroup`.`region`
VALUES ('18','Umbria', 'Centro');
INSERT INTO `toysgroup`.`region`
VALUES ('19','Valle d_Aosta', 'Nord');
INSERT INTO `toysgroup`.`region`
VALUES ('20','Veneto', 'Nord');

-- Inserisco le righe nella tabella sales
INSERT INTO `toysgroup`.`sales`
VALUES ('1','10', '2020-03-15');
INSERT INTO `toysgroup`.`sales`
VALUES ('2','12', '2015-02-22');
INSERT INTO `toysgroup`.`sales`
VALUES ('3','5', '2017-04-10');
INSERT INTO `toysgroup`.`sales`
VALUES ('4','18', '2019-01-30');
INSERT INTO `toysgroup`.`sales`
VALUES ('5','16', '2024-05-23');
INSERT INTO `toysgroup`.`sales`
VALUES ('6','3', '2022-03-08');
INSERT INTO `toysgroup`.`sales`
VALUES ('7','11', '2022-04-25');
INSERT INTO `toysgroup`.`sales`
VALUES ('8','9', '2023-02-14');
INSERT INTO `toysgroup`.`sales`
VALUES ('9','14', '2016-05-09');
INSERT INTO `toysgroup`.`sales`
VALUES ('10','2', '2020-03-27');
INSERT INTO `toysgroup`.`sales`
VALUES ('11','17', '2018-01-24');
INSERT INTO `toysgroup`.`sales`
VALUES ('12','6', '2021-05-14');
INSERT INTO `toysgroup`.`sales`
VALUES ('13','1', '2015-04-04');
INSERT INTO `toysgroup`.`sales`
VALUES ('14','19', '2024-02-08');
INSERT INTO `toysgroup`.`sales`
VALUES ('15','7', '2022-03-22');
INSERT INTO `toysgroup`.`sales`
VALUES ('16','13', '2021-05-02');
INSERT INTO `toysgroup`.`sales`
VALUES ('17','4', '2015-04-18');
INSERT INTO `toysgroup`.`sales`
VALUES ('18','15', '2018-01-17');
INSERT INTO `toysgroup`.`sales`
VALUES ('19','08', '2023-05-21');
INSERT INTO `toysgroup`.`sales`
VALUES ('20','10', '2022-03-01');

-- Inserisco le righe nella tabella product
INSERT INTO `toysgroup`.`product`
VALUES ('1','Macchina da corsa', 'Giocattolo', '7', '3.50');
INSERT INTO `toysgroup`.`product`
VALUES ('2','Bambola', 'Giocattolo', '15', '4.50');
INSERT INTO `toysgroup`.`product`
VALUES ('3','Palloncino', 'Giocattolo', '4', '2.00');
INSERT INTO `toysgroup`.`product`
VALUES ('4','Set di costruzioni', 'Giocattolo', '11', '15.00');
INSERT INTO `toysgroup`.`product`
VALUES ('5','Peluche', 'Giocattolo', '7', '4.00');
INSERT INTO `toysgroup`.`product`
VALUES ('6','Palloncino', 'Giocattolo', '8', '2.00');
INSERT INTO `toysgroup`.`product`
VALUES ('7','Scarabeo', 'Gioco da tavolo', '19', '8.00');
INSERT INTO `toysgroup`.`product`
VALUES ('8','Puzzle', 'Gioco da tavolo', '2', '8.00');
INSERT INTO `toysgroup`.`product`
VALUES ('9','Carte da gioco', 'Gioco da tavolo', '5', '3.50');
INSERT INTO `toysgroup`.`product`
VALUES ('10','Pistola ad acqua', 'Giocattolo all\'aperto', '10', '20.00');
INSERT INTO `toysgroup`.`product`
VALUES ('11','Sudoku', 'Gioco da tavolo', '3', '5.00');
INSERT INTO `toysgroup`.`product`
VALUES ('12','Bicicletta', 'Giocattolo all\'aperto', '10', '20.00');
INSERT INTO `toysgroup`.`product`
VALUES ('13','Pattini', 'Giocattolo all\'aperto', '9', '12.00');
INSERT INTO `toysgroup`.`product`
VALUES ('14','Trottola', 'Giocattolo', '6', '3.00');
INSERT INTO `toysgroup`.`product`
VALUES ('15','Lego', 'Giocattolo', '18', '12.50');
INSERT INTO `toysgroup`.`product`
VALUES ('16','Barbie', 'Giocattolo', '16', '10.00');
INSERT INTO `toysgroup`.`product`
VALUES ('17','Action figure', 'Giocattolo', '20', '5.00');
INSERT INTO `toysgroup`.`product`
VALUES ('18','Macchinina telecomandata', 'Giocattolo', '17', '5.50');
INSERT INTO `toysgroup`.`product`
VALUES ('19','Barbie', 'Giocattolo', '13', '10.00');
INSERT INTO `toysgroup`.`product`
VALUES ('20','Trenino', 'Giocattolo', '5', '8.00');
INSERT INTO `toysgroup`.`product`
VALUES ('21','Casa delle bambole', 'Giocattolo', '14', '18.00');
INSERT INTO `toysgroup`.`product`
VALUES ('22','Cucina giocattolo', 'Giocattolo', '1', '18.00');
INSERT INTO `toysgroup`.`product`
VALUES ('23','Carte da gioco', 'Gioco da tavolo', '12', '3.50');
INSERT INTO `toysgroup`.`product`
VALUES ('24','Cucina giocattolo', 'Giocattolo', '3', '18.00');
INSERT INTO `toysgroup`.`product`
VALUES ('25','Barbie', 'Giocattolo', '8', '10.00');

-- Presento le seguenti query per rispondere agli interrogativi dell'esercitazione

-- 1. Verificare che i campi definiti come PK siano univoci.
-- Per la tabella product eseguo questa query:
SELECT
	idproduct,
    COUNT(*)
FROM
	product
GROUP BY
	1
HAVING
	COUNT(*) =1
;
-- 25 righe su 25 sono presenti una sola volta. Per controprova eseguo questa query:
SELECT
	idproduct,
    COUNT(*)
FROM
	product
GROUP BY
	1
HAVING
	COUNT(*) <>1
;
-- Come volevasi dimostrare, l'output è vuoto.
-- Analogamente, per la tabella region eseguo questa query:
SELECT
	idregion,
    COUNT(*)
FROM
	region
GROUP BY
	1
HAVING
	COUNT(*) =1
;
-- 20 righe su 20 sono presenti una sola volta. Per controprova eseguo questa query:
SELECT
	idregion,
    COUNT(*)
FROM
	region
GROUP BY
	1
HAVING
	COUNT(*) <>1
;
-- Come volevasi dimostrare, l'output è vuoto.
-- Analogamente, per la tabella sales eseguo questa query:
SELECT
	idsales,
    COUNT(*)
FROM
	sales
GROUP BY
	1
HAVING
	COUNT(*) =1
;
-- 20 righe su 20 sono presenti una sola volta. Per controprova eseguo questa query:
SELECT
	idsales,
    COUNT(*)
FROM
	sales
GROUP BY
	1
HAVING
	COUNT(*) <>1
;

-- 2. Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno.
SELECT
	p.productname Prodotto,
    YEAR(s.salesdate) AnnoFatturato,
    SUM(p.price) FatturatoProdotto
FROM
	product p
		JOIN
	sales s
		ON
	p.idsales = s.idsales
GROUP BY
	1, 2
ORDER BY
	1
;

-- 3. Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente.
-- N.B. Sono rappresentate le 20 regioni italiane
SELECT
	r.regionname Regione,
    YEAR(s.salesdate) AnnoFatturato,
    SUM(p.price) FatturatoRegione
FROM
	product p
		LEFT JOIN
	sales s
		ON
	p.idsales = s.idsales
		LEFT JOIN
	region r
		ON
	s.idregion = r.idregion
GROUP BY
	1,2
ORDER BY
	2, 3 DESC
;
-- Alternativamente, si può fare un'analisi in base alle zone d'Italia.
SELECT
	r.zone Zona,
    YEAR(s.salesdate) AnnoFatturato,
    SUM(p.price) FatturatoRegione
FROM
	product p
		LEFT JOIN
	sales s
		ON
	p.idsales = s.idsales
		LEFT JOIN
	region r
		ON
	s.idregion = r.idregion
GROUP BY
	1,2
ORDER BY
	2, 3 DESC
;

-- 4. Qual è la categoria di articoli maggiormente richiesta dal mercato?
-- In base ai prodotti venduti
SELECT
	category CategoriaPiuRichiesta
FROM
	product
GROUP BY
	1
HAVING
	COUNT(*) = (SELECT
					MAX(Quant)
				FROM
					(SELECT category,
								COUNT(*) Quant
					FROM 
						product
                    GROUP BY
						1)
					A)
;
-- In base al fatturato
SELECT
	category CategoriaPiuRichiesta
FROM
	product
GROUP BY
	1
HAVING
	SUM(price) = (SELECT
						MAX(Fatturato)
					FROM
						(SELECT
							category,
							SUM(price) Fatturato
						FROM
							product
						GROUP BY
							category
						)ALFA
					)
;
/*In entrambe le analisi emerge la categoria "Giocattolo" come la più richiesta.
Un'analisi più accurata si avrebbe qualora si identificasse una sottocategorizzazione dei giocattoli,
in base alle dimensioni, alla forma e al loro mercato di riferimento
(es. bambini in età prescolare, dai 6 agli 11 anni, 12+ anni).*/

-- 5. Quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti.
-- Metodo risolutivo #1
SELECT DISTINCT
	p.productname Prodotto
FROM
	product p
		LEFT JOIN
	sales s
		ON
	p.idsales = s.idsales
WHERE
	s.idsales IS NULL
;
-- Metodo risolutivo #2
SELECT DISTINCT
	p.productname Prodotto
FROM
	product p
		LEFT JOIN
	sales s
		ON
	p.idsales = s.idsales
WHERE
	s.salesdate IS NULL
;
-- Entrambi i metodi non mostrano alcun prodotto, in quanto gli articoli riportati sono stati venduti almeno una volta.

-- 6. Esporre l’elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita più recente).
-- In ordine alfabetico per prodotto:
SELECT
	p.productname Articolo,
    MAX(s.salesdate) DataVendita
FROM
	product p
		JOIN
	sales s
		ON
	p.idsales = s.idsales
GROUP BY
	1
ORDER BY
	1
;
-- In ordine cronologico (dal più recente):
SELECT
	p.productname Articolo,
    MAX(s.salesdate) DataVendita
FROM
	product p
		JOIN
	sales s
		ON
	p.idsales = s.idsales
GROUP BY
	1
ORDER BY
	2 DESC
;