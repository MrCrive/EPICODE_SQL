SELECT 
    dimproduct.ProductKey AS CodiceProdotto,
    dimproduct.ProductAlternateKey AS CodProdAlt,
    dimproduct.ModelName AS Modello,
    dimproduct.EnglishProductName AS NomeInglese,
    dimproduct.StandardCost CostoStandard,
    dimproduct.ListPrice AS PrezzoListino,
    dimproduct.ListPrice - dimproduct.StandardCost AS Markup
FROM
	dimproduct
WHERE
	dimproduct.ProductAlternateKey LIKE "FR%" OR "BK%"