SELECT 
    *
FROM
    adv.dimproduct;
SELECT 
    adv.dimproduct.ProductKey AS Codice_prodotto,
    adv.dimproduct.ProductAlternateKey AS Codice_modello,
    adv.dimproduct.EnglishProductName AS nome_inglese,
    adv.dimproduct.Color AS Colore_prodotto,
    adv.dimproduct.StandardCost AS Costo_standard,
    adv.dimproduct.FinishedGoodsFlag AS ProdottoFinito
    -- count(*)
FROM
    adv.dimproduct
WHERE
	adv.dimproduct.FinishedGoodsFlag = 1