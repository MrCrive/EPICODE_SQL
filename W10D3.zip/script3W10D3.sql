SELECT 
	dimproduct.FinishedGoodsFlag AS ProdottiFiniti,
    dimproduct.ListPrice AS PrezzoListino,
    dimproduct.StandardCost AS CostoStandard
FROM
	dimproduct
WHERE
	dimproduct.StandardCost BETWEEN 1000 AND 2000
ORDER BY
	dimproduct.ListPrice;

SELECT
	*
FROM
	dimemployee
WHERE
	SalesPersonFlag = 1;

SELECT 
    *, SalesAmount - TotalProductCost
FROM
    factresellersales
WHERE
    OrderDate >= '2020/01/01'
AND 
	(ProductKey = 597
	OR ProductKey = 598
	OR ProductKey = 477
	OR ProductKey = 214) ;